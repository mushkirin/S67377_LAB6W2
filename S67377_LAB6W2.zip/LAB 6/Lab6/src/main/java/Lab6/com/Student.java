/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab6.com;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Student {  
    private String stuno ;
    private String stuname ;
    private String stuprogram ;

    public String getStuno() {       
        String valid;
        Pattern pt = Pattern.compile("[A-Z0-9]*") ;
        Matcher mt = pt.matcher(stuno) ;
        boolean bl = mt.matches() ;       
        if (bl == true) {
            valid = stuno ;
        }else {
            valid = "invalid" ;
        }
       return valid;
    }
    public String getStuname() {
        return stuname;
    }
    public String getStuprogram() {
        return stuprogram;
    }
    public void setStuno(String stuno) {
        this.stuno = stuno;
    }
    public void setStuname(String stuname) {
        this.stuname = stuname;
    }
    public void setStuprogram(String stuprogram) {
        this.stuprogram = stuprogram;
    } }
