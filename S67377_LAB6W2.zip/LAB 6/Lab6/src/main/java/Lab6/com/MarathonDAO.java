/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab6.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Lab6.com.Database;

public class MarathonDAO {
    private Connection connection ;
    private int result = 0 ;
    
    public MarathonDAO() throws ClassNotFoundException {
        connection = Database.getConnection() ;
    }   
    public int addDetails (Marathon marathon) {
        try {
            String mySQL = "INSERT INTO marathon(icno, name, category) values (?,?,?)" ;
            PreparedStatement ps = connection.prepareStatement(mySQL) ;
            
            System.out.print("IC No \t = " + marathon.getIcno());
            System.out.print("Name \t = " + marathon.getName());
            System.out.print("Category \t = " + marathon.getCategory());
            
            ps.setString(1, marathon.getIcno()) ;
            ps.setString(2, marathon.getName()) ;
            ps.setString(3, marathon.getCategory()) ;
            
            result = ps.executeUpdate() ;
        }
        catch (SQLException e) {
        }
        return result ;
    }    
}
